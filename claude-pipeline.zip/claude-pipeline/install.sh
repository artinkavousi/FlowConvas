#!/usr/bin/env bash
# Spec pipeline installer — copies the pipeline into ~/.claude (global, all projects).
# Non-destructive: backs up anything it would change, never clobbers unrelated config.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/home-claude" && pwd)"
DEST="${CLAUDE_HOME:-$HOME/.claude}"
STAMP="$(date +%Y%m%d-%H%M%S)"

say() { printf '  %s\n' "$1"; }

echo "Installing spec pipeline into: $DEST"
mkdir -p "$DEST/skills"

# 1) Skills — copy our four skills; leaves any other skills untouched.
for skill in spec-research spec-prd spec-plan spec-build spec-review spec-feature; do
  rm -rf "$DEST/skills/$skill"
  cp -R "$SRC/skills/$skill" "$DEST/skills/$skill"
  say "skill installed: /$skill"
done

# 2) Global CLAUDE.md — append our block (backup first); replace it if already present.
MARKER_BEGIN="<!-- BEGIN spec-pipeline -->"
MARKER_END="<!-- END spec-pipeline -->"
BLOCK="$(cat "$SRC/CLAUDE.md")"
if [ -f "$DEST/CLAUDE.md" ]; then
  cp "$DEST/CLAUDE.md" "$DEST/CLAUDE.md.bak-$STAMP"
  # strip any previous pipeline block, then re-append the current one
  awk -v b="$MARKER_BEGIN" -v e="$MARKER_END" '
    $0==b{skip=1} !skip{print} $0==e{skip=0}' "$DEST/CLAUDE.md.bak-$STAMP" > "$DEST/CLAUDE.md"
  printf '\n%s\n' "$BLOCK" >> "$DEST/CLAUDE.md"
  say "CLAUDE.md updated (backup: CLAUDE.md.bak-$STAMP)"
else
  printf '%s\n' "$BLOCK" > "$DEST/CLAUDE.md"
  say "CLAUDE.md created"
fi

# 3) settings.json — never overwrite an existing one; drop an example to merge by hand.
if [ -f "$DEST/settings.json" ]; then
  cp "$SRC/settings.json" "$DEST/settings.pipeline-example.json"
  say "settings.json exists — left yours intact."
  say "  → merge \"model\" and \"permissions.deny\" from settings.pipeline-example.json if you want them."
else
  cp "$SRC/settings.json" "$DEST/settings.json"
  say "settings.json created (default model: sonnet, destructive cmds denied)"
fi

echo
echo "Done. In any project:"
echo "  /model opusplan     # Opus plans, Sonnet builds (recommended)"
echo "  /spec-prd  → /spec-plan → /spec-build → /spec-review"
echo
echo "Artifacts land in that project's ./spec/ folder."
