# Spec Pipeline — a universal global workflow for Claude Code

Install once into `~/.claude/`, then in **any** repo you get a clean, repeatable
path from idea → research → polished PRD → well-designed plan → self-contained
tasks → verified implementation — plus a command to fold new features into an
in-flight project. No framework, no per-project setup, no dependencies.

It's built so the **expensive model plans** and a **cheap model executes** —
because planning produces tasks detailed enough that execution is mechanical. The
output documents borrow the strongest ideas from the best agentic tooling:
research-first grounding, BMAD-style readiness gates and epics/waves, Task-Master
complexity sizing, Superpowers' test-first execution and fresh-context review, and
the skill-authoring conventions (worked examples, gotchas, progressive disclosure).

```
/spec-research → spec/research.md     prior art, options, tradeoffs   (Opus + web)
/spec-prd      → spec/prd.md          what & why                      (Opus)
/spec-plan     → spec/plan.md         design, risks, readiness gate   (Opus)
                 spec/tasks.md         ordered, sized, self-contained tasks
                 spec/decisions.md     ADR-lite log
/spec-build    → implements next task test-first + verifies           (Sonnet/Haiku)
/spec-review   → severity-ranked review of the diff vs the tasks       (fresh context)
/spec-feature  → add a feature to a live project, wired into spec/     (Opus → Sonnet)
```

## Install

```bash
unzip claude-pipeline.zip      # or git clone / cp the folder
cd claude-pipeline
bash install.sh
```

Non-destructive: it copies the six skills into `~/.claude/skills/` (leaving your
other skills alone), appends a delimited block to `~/.claude/CLAUDE.md` (backing up
the original, and idempotent on re-runs), and creates `~/.claude/settings.json` only
if you don't already have one — otherwise it drops `settings.pipeline-example.json`
to merge by hand. Custom location: `CLAUDE_HOME=/path/to/.claude bash install.sh`.
Verify with `claude --doctor`, or type `/spec-prd` in any project.

## Use it

```
/model opusplan        # Opus plans, Sonnet executes — automatic

/spec-research   # optional: grounds the work in prior art + your codebase
/spec-prd        # interviews you, writes a comprehensive spec/prd.md
/spec-plan       # design + sized, ordered, self-contained tasks + readiness gate
/spec-build      # implements the next task test-first, verifies, ticks it off
/spec-review     # independent severity-ranked pass before "done"

/spec-feature    # mid-project: scope a new feature and wire it into spec/
```

`/clear` between stages is encouraged — each stage reloads what the previous one
wrote from `spec/`. Start at `/spec-prd` for well-understood work; reach for
`/spec-research` when the approach is genuinely uncertain.

## Why the output is higher quality

- **Research-grounded.** `/spec-research` resolves "what's the best way" with cited
  evidence and a committed recommendation before requirements are written.
- **Comprehensive but proportional docs.** Templates cover personas, NFR budgets,
  edge cases, data model, interfaces, observability, and rollout — and explicitly
  scale down for small work (drop sections that don't apply).
- **A readiness gate.** `/spec-plan` won't quietly hand off a half-baked plan; it
  emits PASS / CONCERNS / FAIL against a checklist (every FR mapped, no oversized
  task, dependencies acyclic, acceptance runnable).
- **Self-contained, sized tasks.** Each names files, interface, pattern, scope,
  test-first note, and acceptance — so a cheap model just follows.
- **Verified, not asserted.** Execution is test-first; review runs in fresh context
  and is told not to manufacture findings or over-engineer.

## Definition of Done

A task is done only when its acceptance check passes (evidence shown), nothing
outside its scope changed, it matches repo conventions, and `/spec-review` finds no
blocker. "It runs" is not done.

## Customize

- **Folder name:** skills write to `spec/`; find-and-replace `spec/` across the
  `SKILL.md` files for `docs/specs/` etc.
- **Optional quality-gate hook** (auto-format/lint after edits) — add to
  `~/.claude/settings.json`:
  ```json
  "hooks": {
    "PostToolUse": [
      { "matcher": "Edit|Write",
        "hooks": [ { "type": "command",
          "command": "jq -r '.tool_input.file_path' | xargs -r npx prettier --write 2>/dev/null || true" } ] }
    ]
  }
  ```
  Left out of the default so it can't break repos without a formatter.
- **Pin models:** default is `claude-sonnet-4-6`; override per project in
  `.claude/settings.json` or per session with `/model`.

## Optional companions (not required)

```
/plugin install frontend-design@claude-plugins-official   # distinctive UI, not "AI slop"
/plugin install code-review@claude-plugins-official        # bundled diff review
/plugin marketplace add anthropics/skills                  # official skill collection
```
For current library docs during builds, add a Context7 MCP server. Task Master can
consume the PRD this pipeline writes (`task-master parse-prd spec/prd.md`).

## What's in the box

```
claude-pipeline/
├── install.sh
├── README.md
└── home-claude/                  # mirrors ~/.claude/
    ├── CLAUDE.md                  # the flow, model split, Definition of Done, principles
    ├── settings.json             # cheap default model + destructive-cmd guardrails
    └── skills/
        ├── spec-research/ SKILL.md + references/research-template.md
        ├── spec-prd/      SKILL.md + references/prd-template.md
        ├── spec-plan/     SKILL.md + references/{plan,task}-template.md
        ├── spec-build/    SKILL.md
        ├── spec-review/   SKILL.md
        └── spec-feature/  SKILL.md
```
